var fs = require('fs');
var TrackviaAPI = require('trackvia-api');
var pdf = require('html-pdf');
var Handlebars = require('handlebars');
var globalCallback = null;



/*********************************************
 * Configuation specific to this account
 * 
 * Assume no major change to data structure, all changes to 
 * this code to work on different accounts/tables/views
 * should be made here.
 * 
 * If you need to update the template edit the
 * templates/template.hbs file. For more
 * information on the Handlebars template language
 * see http://handlebarsjs.com/
 **********************************************/
// The API key that gives you access to the API
// This is found at https://go.trackvia.com/#/my-info
const API_KEY = '9297f9bbb02b57ed0107b06dbd76a473';

// The name of the user to login as
const USERNAME = 'john.etherton@gmail.com';

// The password of the user to login as
const PASSWORD = 'reedfeed';

// The address of the server you'll be using
const PRODUCTION_SERVER = 'https://go.trackvia.com';

// The numeric ID of the view to pull the data from
// You can find this in the URL of your view
// https://go.trackvia.com/#/apps/1/tables/2/views/3
const VIEW_ID = 39;


/*********************************************
 * Everything below here should only be edited
 * if substantial changes to the data structure
 * that are used to create the PDF are made,
 * or if a change in behavior is needed.
 ********************************************/






// The TrackVia api for interaction with the data
var api = new TrackviaAPI(API_KEY, PRODUCTION_SERVER);

/**
 * Entry point into the micro service. This is where the
 * execution is kicked off
 */
exports.handler = function(event, context, callback) {
    console.log('---  starting  ---');
    globalCallback = callback;
    console.log(event);
    context.callbackWaitsForEmptyEventLoop = false;

    
    //is any data submitted? If so save it to TrackVia and
    //return the thank you web page
    //otherwise, return the webform to collect data
    if(event.data){
        createRecord(event.data);
    } else {
        //collect data with a web format
        generateWebForm();
    }
}


function createRecord(data){
    var api = new TrackviaAPI(API_KEY, PRODUCTION_SERVER);
    api.login(USERNAME, PASSWORD)
    .then(() => {
        console.log('Logged In.');
        console.log("About to create record with");
        console.log(data);
        return api.addRecord(VIEW_ID, data);
    })
    .then((data) => {
        console.log('created record');
        console.log(data);
        if(globalCallback){
                globalCallback(null, "Created record");
            }

        return;
    });
}

/**
 * Create the web form
 */
function generateWebForm(){
    //read in the template file
    fs.readFile('./templates/template.hbs', 'utf-8', function(err, hbsFile) {
        // if there's an error log it.
        if (err) { 
            console.log(err);
            if(globalCallback){
                globalCallback(err, null);
            }
            return;
        }
        // no error so compile the template
        var template = Handlebars.compile(hbsFile);
        var html = template({});
        // print out the HTML just to be sure
        console.log("Created this HTML from the template");
        console.log(html);
        var response = {"content-type": "text/html", "payload": html};

        if(globalCallback){
            globalCallback(null, response);
        }
    });
}
